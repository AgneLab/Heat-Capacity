#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: elana j cope
"""


import numpy as np
import matplotlib.pyplot as plt
from scipy.constants import k, pi, h 
import pandas as pd
from matplotlib import rcParams
from matplotlib.ticker import MaxNLocator
from pymatgen.ext.matproj import MPRester
from collections import Counter
from pymatgen.core.periodic_table import Element  # To get atomic number


#figure settings
rcParams.update({'figure.autolayout': True}) #keeps the axis labels from getting cut off
# These commands modify default figure properties to make them more legible
plt.rcParams['axes.linewidth']    = 2.5
plt.rcParams['lines.linewidth']   = 1.5
plt.rcParams['font.sans-serif']   = 'Arial'
plt.rcParams['font.weight']       = 'bold'
plt.rcParams['axes.labelweight']  = 'bold'
plt.rcParams['axes.titleweight']  =    'bold'
plt.rcParams['axes.labelsize']    = 16
plt.rcParams['font.size'] = 18
plt.rcParams['axes.titlesize']    = 16
plt.rcParams['xtick.labelsize']   = 16
plt.rcParams['ytick.labelsize']  =  16
#plt.rcParams['axes.grid']         = True
plt.rcParams['xtick.major.size']  = 5
plt.rcParams['xtick.major.width'] = 2.5
plt.rcParams['ytick.major.size']  = 5
plt.rcParams['ytick.major.width'] = 2.5
plt.rcParams['lines.markersize']  = 12
plt.rcParams['xtick.minor.visible'] = False
plt.rcParams['ytick.minor.visible'] = False

#%% Cp Model Functions

#Cp model 
def Cp_model(e_raw, g_raw, B_vrh, G_vrh, Density, Molec_Wt, N_atom, V_cell, g_Ef, Temp):

    DF = pd.DataFrame(columns=['e','DOS'])
    DF['e']=pd.Series(e_raw)
    DF['DOS']=pd.Series(g_raw)
    
    # delete all indices with negative energy using a boolean mask
    mask = DF.values[:, 0] >= 0 # energy in column 0 
    pos_dataset = DF.values[mask]

    # replace any negative DOS values with 0
    pos_dataset[pos_dataset[:, 1] < 0, 1] = 0

    e_pos = pos_dataset[:,0] ### these DOS are already in J

    #e_pos = pos_dataset[:,0]/6.241506363094e+21 # filtered energies converted from meV to J
    
    ####use this line instead of the above if DOS is in THz:
    #e_pos = pos_dataset[:,0]*h*1e12 #convert THz to J
    
    g_pos= pos_dataset[:,1] #filtered DOS (negative = 0)

    # normalize the DOS
    g_norm = g_pos/np.trapz(g_pos, e_pos) #normalized with e_pos (in J)

    #check to make sure DOS is normalized to 1. The printed value should equal 1 if the normalization is correct. 
    print(np.trapz(g_norm, e_pos))
    
    #handle division by zero 
    epsilon = 1e-10 #constant to avoid dividing by 0
    Temp = np.array(Temp, dtype=float)
    Temp[Temp < epsilon] = epsilon 
    
    Num_Density = N_atom/(V_cell * 1e-30) # number density in atom/(m^3) 
    Vm = (Molec_Wt/1000)/(Density*1000)  # molar volume in m^3/mol 
    
    #Compute Cv values:
    Cv_vib = [] #vibrational constant volume heat capcity defined
    for T in Temp:
        
        X = e_pos / (k * T)
        
        # Handle division by zero
        denominator = (np.exp(X) - 1)
        denominator[denominator < epsilon] = epsilon
        
        xx = (g_norm * (X**2) * np.exp(X)) / denominator**2 #stuff inside the integral
        integral_T = (k * 3 * Num_Density * np.trapz(xx, e_pos)) #compute the integral for every value of T
        
        Cv_vib.append(integral_T)
    Cv_vib = np.array(Cv_vib)
    
    Cv_elec = ((pi**2) / 3) * (k**2) * g_Ef * Temp #electronic term for Cv
    Cv_total = Cv_vib + Cv_elec #total Cv from vib + elec
    
    #convert bulk and shear modulus values to Pa = (J/m^3)
    G_vrh_Pa = G_vrh*1e9   
    B_vrh_Pa = B_vrh*1e9
    
    #Calculate thermal expansion coefficient and dilation terms
    Alpha =  (27 * Cv_total)/((20 * G_vrh_Pa) + (6 * B_vrh_Pa)) 
    Dilation = ((Alpha**2)*B_vrh_Pa*Temp) 
    
    Cp = (Cv_total + Dilation)*Vm 
    return Cp


#Plotting Function 
def Plot(Temp, Cp, ID):
    #### plot Cp
    fig = plt.figure()
    ax = plt.subplot(1,1,1)
    plt.ylabel('$\mathrm{C_{p}}$ / J$\cdot$mol$^{-1}\cdot$K$^{-1}$')
    plt.xlabel('Temperature / K')

    #set range of axes
    xmin=0
    xmax=max(Temp)
    plt.xlim(xmin, xmax)
    ymin=0
    ymax=max(Cp)
    plt.ylim(ymin, ymax)
    
    #make square graph
    ax.set_aspect((xmax-xmin)/(ymax-ymin))
    #make five tick marks on each axis
    plt.gca().xaxis.set_major_locator(MaxNLocator(integer=True, nbins=6))
    plt.gca().yaxis.set_major_locator(MaxNLocator(integer=True, nbins=6))
    plt.plot(Temp, Cp, '-', color='darkred', linestyle='-', linewidth=3, label='Cp')
    plt.savefig(f'Cp_vs_T_{ID}.png', dpi=800)
    plt.show()
    


# For Electronic Term
API_KEY = "your API key here"
def get_eDOS(material_id): 
   
    # Initialize MPRester with your API key
    with MPRester(API_KEY) as mpr:
    
        dos = mpr.get_dos_by_material_id(material_id) #units= states / eV
        if dos is None:
            dos = np.nan
            dos.energies= np.nan #to avoid dividing by 0
            
        total_density = sum(dos.densities.values()) # Sum over both spins, if present, units = states / eV
        min_index = np.argmin(abs(dos.energies - dos.efermi))
        dos_energies = dos.energies * 1.602177e-19 #convert eV to J, units = J
        
        dos_integral = np.trapz(total_density, dos_energies)
        dos_norm = total_density/dos_integral # J^-1 
        #check to make sure DOS is normalized to 1 
        print('check if normalized (dos_norm/dos_energies:')
        print(np.trapz(dos_norm, dos_energies)) #units = J^-1 * J = unitless 
        
        structure = mpr.get_structure_by_material_id(material_id)
        # Count the occurrences of each element in the unit cell
        element_counts = Counter(site.specie.symbol for site in structure)
        total_electrons = 0
        for element, count in element_counts.items():
            # Get the atomic number (total number of electrons) for the element
            atomic_number = Element(element).Z
            
            # Multiply the atomic number by the number of atoms in the unit cell
            total_electrons += atomic_number * count
           
        cell_volume = structure.volume #in cubic Angstrom
        charge_density = total_electrons/(cell_volume * 1e-30) #unit = states / m^3
        dos_norm_charge = charge_density * dos_norm # unit = states * J^-1 * m^-3 
        eDOS_at_Fermi = dos_norm_charge[min_index] # unit = states * J^-1 * m^-3  
        return eDOS_at_Fermi



#%% ## Example usage

data_input = 'HeatCapacity_DataEntry_ForVDE.csv'
df = pd.read_csv(data_input, header=1)
for i, row in df.iterrows():
    # Initialize an empty list to store DataFrames for each material

    formula = df['Formula'][i]
    ID = df['Material_ID'][i]
    N_atom = df['Num_Atoms'][i]
    Density = df['Density_g_per_cubcm'][i]
    V_cell = df['Vol_Cell_cubAngstrom'][i]
    B_vrh = float(df['B_vrh_Gpa'][i])
    G_vrh = float(df['G_vrh_Gpa'][i])
    Molec_Wt = df['Molecular_Weight_g_per_mol'][i]
    
    #For electronic density of states, either enter in value manually, use API, or enter '0'
    g_Ef = df['Elec_DOS_eF'][i]
    #g_Ef = 0
    #g_Ef = get_eDOS(df['Material_ID'][i])
    
    
    #get the DOS for that material
    DOSdf = pd.read_csv(df['Material_ID'][i]+".csv", header=0)
    e_raw = DOSdf['# e_pos']
    g_raw = DOSdf[' g_norm']
    
    #### use these lines instead of the above if using the .dat file for DFT-determined DOS:
    # DOSdf = pd.read_csv(df['Material_ID'][i] + ".dat", sep='\s+')
    # e_raw = DOSdf['#'].values  # Energy values
    # g_raw = DOSdf['Tetrahedron'].values  # DOS values
    
    Temps = np.arange(5, 600) #define temperatures that should be run
 
    # Call the Cp_model function
    Cp = Cp_model(e_raw, g_raw, B_vrh, G_vrh, Density, Molec_Wt, N_atom, V_cell, g_Ef, Temps)

    result_df = pd.DataFrame({
        'Temp':Temps,
        'Cp': Cp,
    })
    
    # Save the result_df DataFrame to a CSV file for the current material
    result_filename = f'Cp_output_{ID}.csv'
    result_df.to_csv(result_filename, index=False)


    Plot(Temps, Cp, ID)







